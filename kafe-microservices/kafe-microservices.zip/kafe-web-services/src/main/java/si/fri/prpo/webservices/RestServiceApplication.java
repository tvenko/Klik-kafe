package si.fri.prpo.webservices;

import javax.ws.rs.ApplicationPath;

@ApplicationPath("/")
public class RestServiceApplication extends javax.ws.rs.core.Application {

}
