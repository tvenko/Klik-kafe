/**
 * 
 */
/**
 * @author Administrator
 *
 */
package si.fri.prpo.models;