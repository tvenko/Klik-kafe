package si.fri.exercise.restservices.v1;

import javax.ws.rs.ApplicationPath;

@ApplicationPath("/")
public class RestServiceApplication extends javax.ws.rs.core.Application{

}
