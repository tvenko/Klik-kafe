/**
 * 
 */
/**
 * @author Administrator
 *
 */
package si.fri.exercise.mediations;