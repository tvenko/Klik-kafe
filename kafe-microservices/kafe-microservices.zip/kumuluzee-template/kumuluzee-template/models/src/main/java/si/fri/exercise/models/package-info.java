/**
 * 
 */
/**
 * @author Administrator
 *
 */
package si.fri.exercise.models;